import React, { useState, useEffect } from 'react';
import { useGame } from '../../context/GameContext';
import { motion, AnimatePresence } from 'motion/react';

type Suit = '♠' | '♣' | '♥' | '♦';
type Rank = '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K' | 'A';

interface Card {
  id: string;
  suit: Suit;
  rank: Rank;
  value: number;
}

const SUITS: Suit[] = ['♠', '♣', '♥', '♦'];
const RANKS: Rank[] = ['6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
const RANK_VALUES: Record<Rank, number> = { '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14 };

export const Durak: React.FC = () => {
  const { addCoins } = useGame();
  const [deck, setDeck] = useState<Card[]>([]);
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [botHand, setBotHand] = useState<Card[]>([]);
  const [trump, setTrump] = useState<Card | null>(null);
  const [table, setTable] = useState<{ attack: Card; defense?: Card }[]>([]);
  const [turn, setTurn] = useState<'player' | 'bot'>('player');
  const [gameOver, setGameOver] = useState<string | null>(null);

  const createDeck = () => {
    let newDeck: Card[] = [];
    SUITS.forEach(suit => {
      RANKS.forEach(rank => {
        newDeck.push({ id: Math.random().toString(), suit, rank, value: RANK_VALUES[rank] });
      });
    });
    return newDeck.sort(() => Math.random() - 0.5);
  };

  const startNewGame = () => {
    const newDeck = createDeck();
    setPlayerHand(newDeck.splice(0, 6));
    setBotHand(newDeck.splice(0, 6));
    setTrump(newDeck[0]);
    setDeck(newDeck.slice(1));
    setTable([]);
    setTurn('player');
    setGameOver(null);
  };

  useEffect(() => {
    startNewGame();
  }, []);

  const attack = (card: Card) => {
    if (turn !== 'player') return;
    if (table.length > 0 && !table.some(p => p.attack.rank === card.rank || p.defense?.rank === card.rank)) return;
    
    setTable([...table, { attack: card }]);
    setPlayerHand(playerHand.filter(c => c.id !== card.id));
    setTurn('bot');
  };

  const defend = (card: Card, pairIndex: number) => {
    const attackCard = table[pairIndex].attack;
    const isHigherSameSuit = card.suit === attackCard.suit && card.value > attackCard.value;
    const isTrump = card.suit === trump?.suit && attackCard.suit !== trump?.suit;
    
    if (isHigherSameSuit || isTrump) {
      const newTable = [...table];
      newTable[pairIndex].defense = card;
      setTable(newTable);
      setPlayerHand(playerHand.filter(c => c.id !== card.id));
      
      // If all card are defended
      if (newTable.every(p => p.defense)) {
        // Option to continue attack or pass
      }
    }
  };

  // Bot Logic (Simple)
  useEffect(() => {
    if (turn === 'bot' && !gameOver) {
      const timer = setTimeout(() => {
        if (table.length > 0) {
          const lastPair = table[table.length - 1];
          if (!lastPair.defense) {
            // Bot Defending
            const defensible = botHand.find(c => 
              (c.suit === lastPair.attack.suit && c.value > lastPair.attack.value) || 
              (c.suit === trump?.suit && lastPair.attack.suit !== trump?.suit)
            );
            
            if (defensible) {
              const newTable = [...table];
              newTable[table.length - 1].defense = defensible;
              setTable(newTable);
              setBotHand(botHand.filter(c => c.id !== defensible.id));
              setTurn('player');
            } else {
              // Bot takes cards
              setBotHand([...botHand, ...table.flatMap(p => [p.attack, ...(p.defense ? [p.defense] : [])])]);
              setTable([]);
              setTurn('player');
            }
          }
        } else {
          // Bot Attacking
          if (botHand.length > 0) {
            const cardToAttack = botHand.reduce((min, c) => c.value < min.value ? c : min, botHand[0]);
            setTable([{ attack: cardToAttack }]);
            setBotHand(botHand.filter(c => c.id !== cardToAttack.id));
            setTurn('player');
          }
        }
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [turn, table, botHand, gameOver, trump]);

  const finishTurn = () => {
    setTable([]);
    // Draw cards
    const drawForPlayer = Math.max(0, 6 - playerHand.length);
    const drawForBot = Math.max(0, 6 - botHand.length);
    
    const newPlayerCards = deck.slice(0, drawForPlayer);
    const newBotCards = deck.slice(drawForPlayer, drawForPlayer + drawForBot);
    
    setPlayerHand([...playerHand, ...newPlayerCards]);
    setBotHand([...botHand, ...newBotCards]);
    setDeck(deck.slice(drawForPlayer + drawForBot));
    
    setTurn(turn === 'player' ? 'bot' : 'player');
    
    if (deck.length === 0) {
      if (playerHand.length === 0) {
        setGameOver('You Win!');
        addCoins(1000);
      } else if (botHand.length === 0) {
        setGameOver('Bot Wins!');
      }
    }
  };

  return (
    <div className="w-full flex flex-col items-center bg-slate-950/80 p-8 rounded-[3rem] border-2 border-cyan-500/20 backdrop-blur-3xl min-h-[600px] relative overflow-hidden">
      {/* Trump & Deck */}
      <div className="absolute top-8 right-8 flex items-center gap-4">
        {trump && (
          <div className="relative">
            <div className="w-12 h-16 bg-white rounded-lg border-2 border-cyan-500 flex items-center justify-center text-black font-bold text-xl absolute -right-6 top-4 rotate-90">
              {trump.suit}{trump.rank}
            </div>
            <div className="w-16 h-24 bg-cyan-900 rounded-lg border-2 border-white flex items-center justify-center text-white/20 font-black relative z-10">
              {deck.length}
            </div>
          </div>
        )}
      </div>

      <div className="mb-12 text-center">
        <h2 className="text-3xl font-display font-black text-cyan-400 tracking-tighter">ДУРАК</h2>
        <div className="flex justify-center gap-[-20px] items-center h-20 mb-4 scale-75">
          {botHand.map((c, i) => (
            <div key={c.id} className="-ml-10 first:ml-0">
              <CardBack isDurak />
            </div>
          ))}
        </div>
        <p className="text-cyan-400/40 text-xs font-bold uppercase tracking-[0.2em]">Bot has {botHand.length} cards</p>
      </div>

      {/* Table Area */}
      <div className="flex-1 w-full flex flex-wrap gap-6 justify-center items-center py-10 min-h-[200px] border-y border-white/5 my-6">
        {table.map((pair, i) => (
          <div key={i} className="relative w-20 h-28">
            <CardComponent card={pair.attack} scale={0.8} />
            {pair.defense && (
              <div className="absolute top-4 left-4">
                <CardComponent card={pair.defense} scale={0.8} />
              </div>
            )}
          </div>
        ))}
        {table.length > 0 && table.every(p => p.defense) && (
          <button 
            onClick={finishTurn}
            className="px-6 py-2 bg-cyan-500 text-black font-black rounded-full hover:scale-105 active:scale-95 transition-all ml-4"
          >
            БИТО
          </button>
        )}
      </div>

      {/* Player Hand */}
      <div className="w-full flex justify-center flex-wrap gap-2 mt-auto">
        {playerHand.sort((a,b) => a.value - b.value).map((card) => (
          <motion.div 
            key={card.id}
            whileHover={{ y: -20 }}
            onClick={() => table.length === 0 || lastAttackUndefended(table) ? attack(card) : defendLast(card, table, defend)}
          >
            <CardComponent card={card} interactive />
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {gameOver && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-cyan-950/90 backdrop-blur-xl"
          >
            <div className="text-center">
              <h3 className="text-7xl font-display font-black text-cyan-400 mb-10">{gameOver}</h3>
              <button onClick={startNewGame} className="px-12 py-5 bg-cyan-400 text-black rounded-full font-black text-2xl hover:bg-white transition-colors">НОВАЯ ИГРА</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const lastAttackUndefended = (table: { attack: any; defense?: any }[]) => {
  return table.length > 0 && !table[table.length - 1].defense;
};

const defendLast = (card: any, table: any[], defendFn: any) => {
  const idx = table.findIndex(p => !p.defense);
  if (idx !== -1) defendFn(card, idx);
};

const CardBack: React.FC<{ isDurak?: boolean }> = ({ isDurak }) => {
  return (
    <div className={`w-20 h-28 rounded-xl border-2 border-white/20 flex items-center justify-center shadow-xl
      ${isDurak ? 'bg-cyan-950 border-cyan-500/30' : 'bg-pink-700 border-pink-500/30'}`}>
      <div className="w-14 h-20 border-2 border-white/10 rounded-lg flex items-center justify-center">
        <div className={`font-black italic ${isDurak ? 'text-cyan-500/20 text-xs' : 'text-pink-500/20 text-lg'}`}>
          {isDurak ? 'ДУРАК' : 'UNO'}
        </div>
      </div>
    </div>
  );
};

const CardComponent: React.FC<{ card: Card; scale?: number; interactive?: boolean }> = ({ card, scale = 1, interactive }) => {
  const isRed = card.suit === '♥' || card.suit === '♦';
  return (
    <div 
      style={{ transform: `scale(${scale})` }}
      className={`w-20 h-28 bg-white rounded-xl border-2 border-slate-200 flex flex-col items-center justify-between p-2 shadow-xl ${interactive ? 'cursor-pointer hover:border-cyan-400' : ''}`}
    >
      <div className={`self-start font-black text-lg ${isRed ? 'text-red-500' : 'text-black'}`}>
        {card.rank}
      </div>
      <div className={`text-3xl ${isRed ? 'text-red-500' : 'text-black'}`}>
        {card.suit}
      </div>
      <div className={`self-end rotate-180 font-black text-lg ${isRed ? 'text-red-500' : 'text-black'}`}>
        {card.rank}
      </div>
    </div>
  );
};
