import React, { useState, useCallback, useEffect } from 'react';
import { Chessboard } from 'react-chessboard';
import { Chess } from 'chess.js';
import { useGame } from '../../context/GameContext';
import { RefreshCcw, Trophy } from 'lucide-react';

export const ChessGame: React.FC = () => {
  const { addCoins } = useGame();
  const [game, setGame] = useState(new Chess());
  const [moveFrom, setMoveFrom] = useState('');
  const [isGameOver, setIsGameOver] = useState(false);
  const [winner, setWinner] = useState<string | null>(null);

  function makeAMove(move: any) {
    const gameCopy = new Chess(game.fen());
    const result = gameCopy.move(move);
    setGame(gameCopy);
    return result; 
  }

  function makeRandomMove() {
    const possibleMoves = game.moves();
    if (game.isGameOver() || game.isDraw() || possibleMoves.length === 0) return;
    const randomIndex = Math.floor(Math.random() * possibleMoves.length);
    makeAMove(possibleMoves[randomIndex]);
  }

  function onDrop(sourceSquare: string, targetSquare: string) {
    const move = makeAMove({
      from: sourceSquare,
      to: targetSquare,
      promotion: 'q', // always promote to queen for simplicity
    });

    if (move === null) return false;

    // Bot move after a delay
    setTimeout(makeRandomMove, 500);
    return true;
  }

  useEffect(() => {
    if (game.isGameOver()) {
      setIsGameOver(true);
      if (game.isCheckmate()) {
        const winnerColor = game.turn() === 'w' ? 'Black' : 'White';
        setWinner(winnerColor);
        if (winnerColor === 'White') addCoins(2000);
      } else {
        setWinner('Draw');
      }
    }
  }, [game]);

  const resetGame = () => {
    setGame(new Chess());
    setIsGameOver(false);
    setWinner(null);
  };

  return (
    <div className="flex flex-col items-center p-6 bg-slate-900 rounded-[3rem] border-2 border-white/10 shadow-2xl w-full max-w-[600px] mx-auto">
      <div className="flex justify-between w-full mb-6 px-4">
        <h2 className="text-2xl font-display font-black text-white uppercase tracking-widest">Grandmaster Hub</h2>
        <button 
          onClick={resetGame}
          className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/60"
        >
          <RefreshCcw size={20} />
        </button>
      </div>

      <div className="w-full aspect-square relative rounded-xl overflow-hidden shadow-inner border-4 border-slate-800">
        <Chessboard 
          {...{
            position: game.fen(),
            onPieceDrop: onDrop,
            boardOrientation: "white" as const,
            customDarkSquareStyle: { backgroundColor: '#1e293b' },
            customLightSquareStyle: { backgroundColor: '#475569' }
          } as any}
        />
        
        {isGameOver && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center z-10">
            <Trophy className="text-yellow-400 mb-4" size={64} />
            <h3 className="text-4xl font-display font-black text-white mb-2">
              {winner === 'White' ? 'YOU WON!' : winner === 'Draw' ? 'DRAW' : 'BOT WON'}
            </h3>
            <p className="text-white/60 mb-8 font-bold uppercase tracking-widest">
              {winner === 'White' ? '+2000 coins earned' : 'Better luck next time'}
            </p>
            <button 
              onClick={resetGame}
              className="px-10 py-4 bg-white text-black rounded-2xl font-black text-xl hover:scale-105 transition-all outline-none"
            >
              PLAY AGAIN
            </button>
          </div>
        )}
      </div>

      <div className="mt-8 grid grid-cols-2 gap-4 w-full text-center">
        <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
          <p className="text-white/40 text-[10px] font-black uppercase mb-1">Current Turn</p>
          <p className="text-white font-bold">{game.turn() === 'w' ? 'White (You)' : 'Black (Bot)'}</p>
        </div>
        <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
          <p className="text-white/40 text-[10px] font-black uppercase mb-1">Status</p>
          <p className={`font-bold ${game.isCheck() ? 'text-red-400' : 'text-white'}`}>
            {game.isCheck() ? 'CHECK!' : 'Playing'}
          </p>
        </div>
      </div>
    </div>
  );
};
