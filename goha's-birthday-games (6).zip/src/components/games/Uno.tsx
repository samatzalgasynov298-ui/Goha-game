import React, { useState, useEffect, useCallback } from 'react';
import { useGame } from '../../context/GameContext';
import { motion, AnimatePresence } from 'motion/react';

type Color = 'Red' | 'Blue' | 'Green' | 'Yellow' | 'Wild';
type Value = '0' | '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | 'Skip' | 'Reverse' | '+2' | 'Wild';

interface Card {
  id: string;
  color: Color;
  value: Value;
}

const COLORS: Color[] = ['Red', 'Blue', 'Green', 'Yellow'];
const VALUES: Value[] = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'Skip', 'Reverse', '+2'];

export const Uno: React.FC = () => {
  const { addCoins } = useGame();
  const [deck, setDeck] = useState<Card[]>([]);
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [botHand, setBotHand] = useState<Card[]>([]);
  const [discardPile, setDiscardPile] = useState<Card[]>([]);
  const [turn, setTurn] = useState<'player' | 'bot'>('player');
  const [gameOver, setGameOver] = useState<string | null>(null);

  const createDeck = () => {
    let newDeck: Card[] = [];
    COLORS.forEach(color => {
      VALUES.forEach(value => {
        newDeck.push({ id: Math.random().toString(), color, value });
        if (value !== '0') newDeck.push({ id: Math.random().toString(), color, value });
      });
    });
    return newDeck.sort(() => Math.random() - 0.5);
  };

  const startNewGame = () => {
    const newDeck = createDeck();
    setPlayerHand(newDeck.splice(0, 7));
    setBotHand(newDeck.splice(0, 7));
    setDiscardPile([newDeck.pop()!]);
    setDeck(newDeck);
    setTurn('player');
    setGameOver(null);
  };

  useEffect(() => {
    startNewGame();
  }, []);

  const drawCard = (handType: 'player' | 'bot') => {
    if (deck.length === 0) setDeck(createDeck());
    const newCard = deck[0];
    const restDeck = deck.slice(1);
    
    if (handType === 'player') setPlayerHand([...playerHand, newCard]);
    else setBotHand([...botHand, newCard]);
    
    setDeck(restDeck);
    setTurn(handType === 'player' ? 'bot' : 'player');
  };

  const playCard = (card: Card, handType: 'player' | 'bot') => {
    const topCard = discardPile[discardPile.length - 1];
    if (card.color === topCard.color || card.value === topCard.value || card.color === 'Wild') {
      setDiscardPile([...discardPile, card]);
      
      if (handType === 'player') {
        const newHand = playerHand.filter(c => c.id !== card.id);
        setPlayerHand(newHand);
        if (newHand.length === 0) {
          setGameOver('You Win!');
          addCoins(500);
        }
      } else {
        const newHand = botHand.filter(c => c.id !== card.id);
        setBotHand(newHand);
        if (newHand.length === 0) setGameOver('Bot Wins!');
      }
      
      setTurn(handType === 'player' ? 'bot' : 'player');
    }
  };

  // Bot Turn
  useEffect(() => {
    if (turn === 'bot' && !gameOver) {
      const timer = setTimeout(() => {
        const topCard = discardPile[discardPile.length - 1];
        const playableCard = botHand.find(c => c.color === topCard.color || c.value === topCard.value);
        if (playableCard) {
          playCard(playableCard, 'bot');
        } else {
          drawCard('bot');
        }
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [turn, discardPile, botHand, gameOver]);

  return (
    <div className="w-full flex flex-col items-center bg-slate-900/80 p-6 rounded-[2.5rem] border-2 border-pink-500/20 backdrop-blur-xl min-h-[500px]">
      <div className="flex justify-between w-full mb-6">
        <h2 className="text-2xl font-display font-black text-pink-500">UNO</h2>
        <div className="flex gap-4">
          <div className="bg-white/5 px-4 py-2 rounded-xl text-xs font-bold">BOT: {botHand.length} cards</div>
          <div className="bg-pink-500/20 px-4 py-2 rounded-xl text-xs font-bold text-pink-400">TURN: {turn.toUpperCase()}</div>
        </div>
      </div>

      {/* Bot Hand (Hidden) */}
      <div className="w-full flex justify-center h-24 mb-10 overflow-hidden scale-75 pt-4">
        <div className="flex gap-[-40px] justify-center items-start">
          {botHand.map((card, i) => (
            <div key={card.id} className="-ml-14 first:ml-0">
              <CardBack />
            </div>
          ))}
        </div>
      </div>

      {/* Discard & Deck */}
      <div className="flex gap-8 mb-16 relative">
        <div onClick={() => turn === 'player' && drawCard('player')} className="w-24 h-36 bg-pink-600 rounded-xl border-4 border-white flex items-center justify-center cursor-pointer hover:rotate-2 shadow-xl shadow-pink-600/30">
          <span className="text-white font-black text-3xl italic">UNO</span>
        </div>
        <div className="w-24 h-36 bg-slate-800 rounded-xl border-4 border-white flex items-center justify-center shadow-xl relative">
          {discardPile.length > 0 && (
            <CardComponent card={discardPile[discardPile.length - 1]} />
          )}
        </div>
      </div>

      {/* Player Hand */}
      <div className="w-full relative flex justify-center h-48">
        <div className="flex gap-[-20px] items-end justify-center">
          {playerHand.map((card, i) => (
            <motion.div 
              key={card.id}
              whileHover={{ y: -40, zIndex: 10 }}
              onClick={() => turn === 'player' && playCard(card, 'player')}
              className="-ml-10 first:ml-0 cursor-pointer"
            >
              <CardComponent card={card} interactive />
            </motion.div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {gameOver && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md rounded-[2.5rem]"
          >
            <div className="text-center">
              <h3 className="text-6xl font-display font-black text-pink-500 mb-8">{gameOver}</h3>
              <button onClick={startNewGame} className="px-10 py-4 bg-white text-pink-600 rounded-2xl font-black text-xl hover:scale-105 active:scale-95 transition-all">PLAY AGAIN</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const CardBack: React.FC = () => {
  return (
    <div className="w-24 h-36 bg-pink-700 rounded-xl border-4 border-white/20 flex items-center justify-center shadow-lg">
      <div className="w-16 h-24 border-2 border-white/10 rounded-lg flex items-center justify-center rotate-12">
        <span className="text-pink-500/20 font-black text-2xl italic">UNO</span>
      </div>
    </div>
  );
};

const CardComponent: React.FC<{ card: Card; interactive?: boolean }> = ({ card, interactive }) => {
  const bgColor = {
    Red: 'bg-red-500',
    Blue: 'bg-blue-500',
    Green: 'bg-green-500',
    Yellow: 'bg-yellow-400',
    Wild: 'bg-black'
  }[card.color];

  return (
    <div className={`w-24 h-36 ${bgColor} rounded-xl border-4 border-white flex flex-col items-center justify-between p-2 shadow-lg ${interactive ? 'hover:shadow-pink-500/50' : ''}`}>
      <span className="self-start text-white font-black text-sm">{card.value}</span>
      <div className="w-16 h-20 bg-white rounded-full flex items-center justify-center rotate-12">
        <span className={`${bgColor.replace('bg-', 'text-')} font-black text-3xl italic`}>{card.value}</span>
      </div>
      <span className="self-end text-white font-black text-sm rotate-180">{card.value}</span>
    </div>
  );
};
